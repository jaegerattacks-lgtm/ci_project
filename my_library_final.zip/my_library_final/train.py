from idlelib import history

import numpy as np
import copy


def train(model, loss_fn, optimizer, x_train, y_train, x_val=None, y_val=None, epochs=100, batch_size=32, verbose=True):


    # Dictionary to store loss history for plotting later
    history = {'train_loss': [], 'val_loss': []}

    n_samples = x_train.shape[0]

    best_val_loss = float('inf')  # Initialize with infinity
    best_weights = []  # List to store the best weights

    if batch_size is None:
        batch_size = n_samples

    for epoch in range(epochs):

        indices = np.arange(n_samples)
        np.random.shuffle(indices)
        x_shuffled = x_train[indices]
        y_shuffled = y_train[indices]

        train_loss = 0
        num_batches = 0
        patience_counter = 0

        # Mini-batch loop
        for i in range(0, n_samples, batch_size):

            x_batch = x_shuffled[i: i + batch_size]
            y_batch = y_shuffled[i: i + batch_size]

            # B) Forward Pass
            output = model.forward(x_batch)


            current_loss = loss_fn.forward(output, y_batch)
            train_loss += current_loss
            num_batches += 1

            # D) Backward Pass
            grad = loss_fn.backward()
            model.backward(grad)

            # E) Update Weights (Optimizer Step)
            for layer in model.layers:
                # Check if layer has weights (skip activation layers)
                if hasattr(layer, 'W'):
                    optimizer.step(layer)

        # Calculate average training loss for this epoch
        avg_train_loss = train_loss / num_batches
        history['train_loss'].append(avg_train_loss)

        # --- 2. Validation Phase ---
        val_msg = ""
        stop_training = False
        if x_val is not None and y_val is not None:
            val_out = model.forward(x_val)
            val_current_loss = loss_fn.forward(val_out, y_val)
            history['val_loss'].append(val_current_loss)

            val_msg = f" | Val Loss: {val_current_loss:.6f}"

            # --- 3. Save Best Weights (Checkpointing) ---
            # If current validation loss is better than the best recorded so far
            if val_current_loss < best_val_loss:
                best_val_loss = val_current_loss
                val_msg += " 🏆 (Saved)"
                patience_counter=0

                best_weights = []
                for layer in model.layers:
                    if hasattr(layer, 'W'):
                        layer_copy = {
                            'W': np.copy(layer.W),
                            'b': np.copy(layer.b)
                        }
                        best_weights.append(layer_copy)
                    else:
                        best_weights.append(None)
                        patience_counter=+1
            else: patience_counter=+1
        if patience_counter==5:
            stop_training = True

                        # Print progress
        if verbose and (epoch % 1 == 0 or epoch == epochs - 1):  # Print every epoch
            print(f"Epoch {epoch + 1}/{epochs} | Train Loss: {avg_train_loss:.6f}{val_msg}")
        if stop_training:
            print(f"\n🛑 Early Stopping! No improvement for {5} epochs.")
            break

    # --- 4. Restore Best Weights ---
    # After training ends, load the weights that achieved the lowest validation loss
    if x_val is not None and best_weights:
        print("\n🔄 Restoring best weights from validation checkpoint...")
        for i, layer in enumerate(model.layers):
            if hasattr(layer, 'W') and best_weights[i] is not None:
                layer.W = best_weights[i]['W']
                layer.b = best_weights[i]['b']
    return history