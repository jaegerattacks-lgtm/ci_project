import numpy as np


def train(model, loss_fn, optimizer, x_train, y_train, epochs=100, batch_size=32, verbose=True):

    loss_history = []
    n_samples = x_train.shape[0]

    if batch_size is None:
        batch_size = n_samples
    for epoch in range(epochs):
        # 1. Shuffling: لخبطة الداتا في بداية كل Epoch (مهم جداً)
        indices = np.arange(n_samples)
        np.random.shuffle(indices)
        x_shuffled = x_train[indices]
        y_shuffled = y_train[indices]

        epoch_loss = 0
        num_batches = 0

        # 2. Mini-batch Loop:
        for i in range(0, n_samples, batch_size):

            x_batch = x_shuffled[i: i + batch_size]
            y_batch = y_shuffled[i: i + batch_size]

            #  Forward Pass
            output = model.forward(x_batch)

            #  Calculate Loss
            current_loss = loss_fn.forward(output, y_batch)
            epoch_loss += current_loss
            num_batches += 1

            # د) Backward Pass
            grad = loss_fn.backward()
            model.backward(grad)

            #  Update Weights (Optimizer Step)
            for layer in model.layers:
                if hasattr(layer, 'W'):
                    optimizer.step(layer)

        avg_loss = epoch_loss / num_batches
        loss_history.append(avg_loss)

        if verbose and (epoch % 1 == 0 or epoch == epochs - 1):
            print(f"Epoch {epoch + 1}/{epochs} | Loss: {avg_loss:.6f}")

    return loss_history