import numpy as np
import urllib.request
import os


def load_mnist_manual():
    path = 'mnist.npz'
    if not os.path.exists(path):
        print("⬇️ Downloading mnist.npz...")
        url = 'https://storage.googleapis.com/tensorflow/tf-keras-datasets/mnist.npz'
        urllib.request.urlretrieve(url, path)

    with np.load(path) as f:
        x_train_val, y_train_val = f['x_train'], f['y_train']
        x_test, y_test = f['x_test'], f['y_test']

   #flateen
    x_train_val = x_train_val.reshape(-1, 784)
    x_test = x_test.reshape(-1, 784)
   #normalization
    x_train_val = x_train_val/255.0
    x_test = x_test/255.0

    split_idx = int(x_train_val.shape[0] * (1 - 0.1))
    split_idy = int(y_train_val.shape[0] * (1 - 0.1))

    x_train=x_train_val[:split_idx]
    y_train=y_train_val[:split_idy]

    x_val = x_train_val[split_idx:]
    y_val = y_train_val[split_idy:]
    return (x_train, y_train), (x_test, y_test), (x_val, y_val)
